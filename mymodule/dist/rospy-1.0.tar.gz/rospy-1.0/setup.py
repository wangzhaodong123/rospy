from distutils.core import setup

setup(
    name='rospy',
    version="1.0",
    description="this is a test of the setup",
    author="qiao",
    author_email="no7david123@gmail.com",
    url='https://www.deng.io',
    packages=['rospy']
)
